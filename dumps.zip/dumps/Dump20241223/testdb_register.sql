-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: testdb
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `register` (
  `idregister` int NOT NULL AUTO_INCREMENT,
  `ts` datetime NOT NULL,
  `product` int NOT NULL,
  `quantite` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `n_total` decimal(10,2) DEFAULT NULL,
  `n_quantite` int DEFAULT NULL,
  `n_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`idregister`),
  KEY `fk_register_products_idx` (`product`),
  CONSTRAINT `fk_register_products` FOREIGN KEY (`product`) REFERENCES `products` (`idproducts`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `register`
--

LOCK TABLES `register` WRITE;
/*!40000 ALTER TABLE `register` DISABLE KEYS */;
INSERT INTO `register` VALUES (60,'2024-12-06 14:08:08',3,10,10.00,100.00,100.00,10,10.00),(61,'2024-12-06 14:08:17',4,10,5.00,50.00,50.00,10,5.00),(62,'2024-12-06 14:08:27',5,10,7.00,70.00,70.00,10,7.00),(63,'2024-12-06 14:08:38',4,10,6.00,60.00,110.00,20,5.50),(64,'2024-12-06 14:08:59',3,10,14.00,140.00,240.00,20,12.00),(65,'2024-12-06 14:09:24',3,-6,12.00,-72.00,168.00,14,12.00),(66,'2024-12-06 14:09:43',3,-2,12.00,-24.00,144.00,12,12.00),(67,'2024-12-06 14:09:59',3,6,16.00,96.00,240.00,18,13.33),(68,'2024-12-06 14:10:27',3,-2,13.33,-26.66,213.34,16,13.33),(69,'2024-12-11 13:01:11',3,-4,13.33,-53.32,160.02,12,13.34),(70,'2024-12-11 13:01:31',4,-2,5.50,-11.00,99.00,18,5.50),(71,'2024-12-23 10:56:18',4,-1,5.50,-5.50,93.50,17,5.50),(72,'2024-12-23 12:09:37',4,-8,5.50,-44.00,49.50,9,5.50);
/*!40000 ALTER TABLE `register` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `register_BEFORE_INSERT` BEFORE INSERT ON `register` FOR EACH ROW BEGIN
	declare let_total decimal(10,2);
    declare var_total, var_price decimal(10,2);
    declare cnt, var_quantite INT;

    select count(n_total) into cnt from register where product = NEW.product
	order by ts desc limit 1;    
	if cnt > 0 then
		-- Подстанавливаем цену реализации
		if NEW.quantite < 0 then
			select n_price into var_price from register where product = NEW.product
			order by ts desc limit 1;
			set NEW.price = var_price;
		end if;
	end if;
    
    set let_total = NEW.price * NEW.quantite;
    set NEW.total = let_total;
    set NEW.ts = now();
    
    if cnt = 0 then
		set NEW.n_total = let_total;
        set NEW.n_quantite = NEW.quantite;
	else
		begin
            -- Считаем n_total
            select n_total into var_total from register where product = NEW.product          
			order by ts desc limit 1;
			set NEW.n_total = var_total + let_total;
            -- Считаем n_quantite
            select n_quantite into var_quantite from register where product = NEW.product
			order by ts desc limit 1;
            set NEW.n_quantite = NEW.quantite + var_quantite;
        end;
	end if;
    set NEW.n_price = NEW.n_total / NEW.n_quantite;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `register_AFTER_INSERT` AFTER INSERT ON `register` FOR EACH ROW BEGIN
	if NEW.quantite < 0 then
		insert into profit(idregister, quantite, price, total, product)
		values (NEW.idregister, -NEW.quantite, NEW.price, -NEW.total, NEW.product);
	end if;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-23 12:51:41
