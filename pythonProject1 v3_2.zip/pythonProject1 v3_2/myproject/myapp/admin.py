from django.contrib import admin
from .models import Profit, Percent, Products, Register


admin.site.register(Profit)
admin.site.register(Percent)
admin.site.register(Products)
admin.site.register(Register)